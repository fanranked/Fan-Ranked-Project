const mysql = require('mysql');
const express = require('express');
const bodyparser = require('body-parser');
var app = express();
//Configuring express server
app.use(bodyparser.json());

function startup()
{
    console.log("Hello World")

    //MySQL details
    let mysqlConnection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'Test1234',
        database: 'polls',
        multipleStatements: true
    });
    mysqlConnection.connect((err) => {
        if(!err)
            console.log('Connection Established Successfully');
        else
            console.log('Connection Failed!'+ JSON.stringify(err,undefined,2));
    });


    //Establish the server connection //PORT ENVIRONMENT VARIABLE
    const port = process.env.PORT || 8082;
    app.listen(port, () => console.log(`Listening on port ${port}..`));
    app.use('/static', express.static('./html'));

    app.get('/poll' , (req, res) => {
        console.log("/poll")
        mysqlConnection.query('SELECT * FROM players ORDER BY RAND() LIMIT 4', (err, rows, fields) => {
            if (!err)
                res.send(rows);
            else
                console.log(err);
        })
        //res.send({"items":[{"label":"Jim", "guid": "aaa"}, {"label":"Joe", "guid": "bbb"}, {"label":"George", "guid": "ccc"}, {"label":"Fred", "guid": "ddd"}]});
    });

    app.get('/poll/results' , (req, res) => {
        console.log("/poll/results")
        mysqlConnection.query('SELECT * FROM players ', (err, rows, fields) => {
            if (!err)
                res.send(rows);
            else
                console.log(err);
        })
    });

    app.post('/poll' , (req, res) => {
        console.log("Response", req.body)
        var data = req.body
        mysqlConnection.query("UPDATE players SET count = count + 1 WHERE guid = ?", [data["poll"]], (err, rows, fields) => {
            if (!err)
                res.send({"response":"ok"});
            else
            {
                console.log(err);
                res.send({"response":"err", "message": err});
            }
        })

        //res.send({});
    });
}

startup();